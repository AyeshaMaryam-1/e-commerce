import Image from "next/image";

export default function Home() {
  return (
      <div>
        <div className="flex">
          <ul className="ml-28">
            <li className="flex">Woman&apos;s Fashion 
              <svg xmlns="http://www.w3.org/2000/svg" width={12} height={24} viewBox="0 0 12 24" className="ml-14">
                <path fill="black" fillRule="evenodd" d="M10.157 12.711L4.5 18.368l-1.414-1.414l4.95-4.95l-4.95-4.95L4.5 5.64l5.657 5.657a1 1 0 0 1 0 1.414"></path>
              </svg>
            </li><br />
            <li className="flex">Men&apos;s Fashion
              <svg xmlns="http://www.w3.org/2000/svg" width={12} height={24} viewBox="0 0 12 24" className="ml-20">
                <path fill="black" fillRule="evenodd" d="M10.157 12.711L4.5 18.368l-1.414-1.414l4.95-4.95l-4.95-4.95L4.5 5.64l5.657 5.657a1 1 0 0 1 0 1.414"></path>
              </svg>             
            </li><br />
            <li>Electronics</li><br />
            <li>Home & Lifestyle</li><br />
            <li>Medicine</li><br />
            <li>Sports & Outdoor</li><br />
            <li>Baby&apos;s & Toys</li><br />
            <li>Groceries & Pets</li><br />
            <li>Health & Beauty</li><br />
          </ul>
          <div className="h-100 -mt-12 w-px bg-gray-300 ml-8"></div>
          <Image className="ml-12" 
              src="/Frame 560.png"
              alt="img"
              width={892}
              height={344}/>
        </div>
        <div className="mt-24">
          <div className="flex">
            <span className="ml-28 bg-[#DB4444] rounded w-6 h-8"></span>
            <h1 className=" ml-6 text-[#DB4444]">Today&apos;s</h1>
          </div>
        </div>
      </div>
    );
}
