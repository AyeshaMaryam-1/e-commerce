export default function Wishlist(){
    return(
        <div>
            
        </div>
    )
}